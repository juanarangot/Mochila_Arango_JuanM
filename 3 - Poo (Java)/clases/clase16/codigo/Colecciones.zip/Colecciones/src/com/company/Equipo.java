package com.company;

import java.util.ArrayList;
import java.util.List;

public class Equipo {
    private String nombre;
    private List<Jugador> jugadores;

    public Equipo(String nombre) {
        this.nombre = nombre;

        jugadores = new ArrayList<Jugador>();
    }

    public void addJugador(Jugador unJugador){
        jugadores.add(unJugador);
    }

    public void removeJugador(Jugador jugador){
        jugadores.remove(jugador);
    }

    public void mostrarJugadoresTitulares(){
        jugadores.sort(null);

        for (Jugador jugador : jugadores) {

            if (jugador.getTitular()) {
                System.out.println(jugador.toString());
            }

        }
    }

    public int getCantidadJugadoresLesionados(){
        int cantidadJugadoresLesionados = 0;

        for (Jugador jugador : jugadores) {

            if (jugador.getTitular() && jugador.getLesionado()){
                cantidadJugadoresLesionados++;
            }

        }

        return cantidadJugadoresLesionados;
    }
}
